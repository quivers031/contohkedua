﻿namespace WindowsFormsApp20
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rb_Muncul = new System.Windows.Forms.RadioButton();
            this.rb_Hilang = new System.Windows.Forms.RadioButton();
            this.lbl_Cetak = new System.Windows.Forms.Label();
            this.tb_Change = new System.Windows.Forms.TextBox();
            this.btn_Change = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_jumlah = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rb_Muncul
            // 
            this.rb_Muncul.AutoSize = true;
            this.rb_Muncul.Location = new System.Drawing.Point(23, 80);
            this.rb_Muncul.Name = "rb_Muncul";
            this.rb_Muncul.Size = new System.Drawing.Size(60, 17);
            this.rb_Muncul.TabIndex = 0;
            this.rb_Muncul.TabStop = true;
            this.rb_Muncul.Text = "Muncul";
            this.rb_Muncul.UseVisualStyleBackColor = true;
            this.rb_Muncul.CheckedChanged += new System.EventHandler(this.rb_Muncul_CheckedChanged);
            // 
            // rb_Hilang
            // 
            this.rb_Hilang.AutoSize = true;
            this.rb_Hilang.Location = new System.Drawing.Point(129, 80);
            this.rb_Hilang.Name = "rb_Hilang";
            this.rb_Hilang.Size = new System.Drawing.Size(55, 17);
            this.rb_Hilang.TabIndex = 1;
            this.rb_Hilang.TabStop = true;
            this.rb_Hilang.Text = "Hilang";
            this.rb_Hilang.UseVisualStyleBackColor = true;
            // 
            // lbl_Cetak
            // 
            this.lbl_Cetak.AutoSize = true;
            this.lbl_Cetak.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cetak.Location = new System.Drawing.Point(12, 117);
            this.lbl_Cetak.Name = "lbl_Cetak";
            this.lbl_Cetak.Size = new System.Drawing.Size(280, 33);
            this.lbl_Cetak.TabIndex = 2;
            this.lbl_Cetak.Text = "Aku seorang kapiten";
            // 
            // tb_Change
            // 
            this.tb_Change.Location = new System.Drawing.Point(23, 12);
            this.tb_Change.Name = "tb_Change";
            this.tb_Change.Size = new System.Drawing.Size(132, 20);
            this.tb_Change.TabIndex = 3;
            // 
            // btn_Change
            // 
            this.btn_Change.Location = new System.Drawing.Point(23, 38);
            this.btn_Change.Name = "btn_Change";
            this.btn_Change.Size = new System.Drawing.Size(75, 23);
            this.btn_Change.TabIndex = 4;
            this.btn_Change.Text = "Change";
            this.btn_Change.UseVisualStyleBackColor = true;
            this.btn_Change.Click += new System.EventHandler(this.btn_Change_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Jumlah Huruf";
            // 
            // lb_jumlah
            // 
            this.lb_jumlah.AutoSize = true;
            this.lb_jumlah.Location = new System.Drawing.Point(93, 165);
            this.lb_jumlah.Name = "lb_jumlah";
            this.lb_jumlah.Size = new System.Drawing.Size(69, 13);
            this.lb_jumlah.TabIndex = 6;
            this.lb_jumlah.Text = "Jumlah Huruf";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_jumlah);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Change);
            this.Controls.Add(this.tb_Change);
            this.Controls.Add(this.lbl_Cetak);
            this.Controls.Add(this.rb_Hilang);
            this.Controls.Add(this.rb_Muncul);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rb_Muncul;
        private System.Windows.Forms.RadioButton rb_Hilang;
        private System.Windows.Forms.Label lbl_Cetak;
        private System.Windows.Forms.TextBox tb_Change;
        private System.Windows.Forms.Button btn_Change;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_jumlah;
    }
}

