﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rb_Muncul_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Muncul.Checked == true)
            {
                lbl_Cetak.Visible = true;
            }
            else if (rb_Hilang.Checked == true)
            {
                lbl_Cetak.Visible = false;
            }
        }

        private void btn_Change_Click(object sender, EventArgs e)
        {
            lbl_Cetak.Text = tb_Change.Text;
            lb_jumlah.Text = tb_Change.Text.Length.ToString();
        }
    }
}
